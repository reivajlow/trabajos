# Ingresar elementos de las 3 tablas


def recortar_nombre_pais(pais):
    pais = pais.lower()
    vocales = ('a', 'e', 'i', 'o', 'u')
    for letra in vocales:
        pais = pais.replace(letra, "")
    if len(pais) > 3:
        pais = pais[0:3]
    return pais


def ingreso_jugador(nombre, apellido, aka, pais, equipo, fecha_nacimiento, genero, rol, conexion):
    abre = recortar_nombre_pais(pais)
    cursorinsert = conexion.cursor()
    consulta2 = "if exists (select * from pais where NombrePais = '" + pais + "')" "select PaisID from pais where NombrePais ='" + pais + "' " "else INSERT INTO pais (NombrePais, AbreviacionPais, EstadoPais) VALUES ('" + pais + "', '" + abre + "', 'activo')"
    cursorinsert.execute(consulta2)
    cursorinsert.commit()
    cursorinsert.close()
    cursorinsert = conexion.cursor()
    consulta3 = "if exists (select * from equipo where EquipoNombre = '" + equipo + "')" "select EquipoID from equipo where EquipoNombre = '" + equipo + "' " "else INSERT INTO equipo (EquipoNombre, EquipoEstado) VALUES ('" + equipo + "', 'activo')"
    cursorinsert.execute(consulta3)
    cursorinsert.commit()
    cursorinsert.close()
    # ano-mes-dia
    cursorinsert = conexion.cursor()
    consulta = "INSERT INTO jugador (NombreJugador, ApellidoJugador," \
               "AKAJugador, PaisJugador, AbreviacionPais, EquipoJugador, FechaNacimiento, Genero, RolJugador, " \
               "EstadoJugador)" \
               " VALUES ('" + nombre + "', '" + apellido + "', '" + aka + "', '" + pais + "', '" + abre + "', '" + equipo + "', '" + fecha_nacimiento + "', '" + genero + "', '" + rol + "', 'activo')"
    cursorinsert.execute(consulta)
    cursorinsert.commit()
    cursorinsert.close()


def ingreso_pais(nombre, conexion):
    # falta robustez pa que no se caiga cuando se pone uno nuevo, solo bloquear consulta
    nombre = input("Ingrese el nombre: ")
    abrePais = recortar_nombre_pais(nombre)
    cursorinsert = conexion.cursor()
    consulta = "INSERT INTO pais (NombrePais, AbreviacionPais, EstadoPais) VALUES ('" + nombre + "', '" + abrePais + "', 'activo')"
    cursorinsert.execute(consulta)
    cursorinsert.commit()
    cursorinsert.close()


def ingreso_equipo(nombre, conexion):
    nombre = input("Ingrese el nombre: ")
    cursorinsert = conexion.cursor()
    consulta = "INSERT INTO equipo (EquipoNombre, EquipoEstado) VALUES ('" + nombre + "', 'activo')"
    cursorinsert.execute(consulta)
    cursorinsert.commit()
    cursorinsert.close()


def ingreso_registro(idjugador, idequipo, fechainicio, fechatermino, conexion):
    # como llamar a las demas funciones o hacer una aparte, en caso que el jugador no exista, queda muy largo
    # ojo, ano-mes-dia
    fechainicio = input("La fecha de inicio: ")
    # ojo, puede ser nulo, para pon
    fechatermino = input("La fecha de termino: ")
    cursorinsert = conexion.cursor()
    consulta = "INSERT INTO registro (JugadorID, EquipoID, FechaInicio, FechaTermino, EstadoRegistro) VALUES ('" + idjugador + "', '" + idequipo + "', '" + fechainicio + "', '" + fechatermino + "', 'activo')"
    cursorinsert.execute(consulta)
    cursorinsert.commit()
    cursorinsert.close()


if __name__ == "__main__":
    # no funcionan por los parametros, sacar para probar
    pass
    # ingreso_jugador()
    # ingreso_pais()
    # ingreso_equipo()
    # ingreso_registro()
