from model.ingreso import recortar_nombre_pais


def ver_jugadores(conexion):
    cursor = conexion.cursor()
    consulta = "SELECT JugadorID, NombreJugador, AKAJugador from Jugador"
    cursor.execute(consulta)
    resu = cursor.fetchall()
    cursor.commit()
    cursor.close()
    return resu


def ver_jugador(id, conexion):
    cursor = conexion.cursor()
    consulta = "SELECT * from Jugador where JugadorID = '" + id + "' and EstadoJugador = 'activo'"
    cursor.execute(consulta)
    resu = cursor.fetchall()
    cursor.commit()
    cursor.close()
    return resu


# tomar los elementos de la lista del jugador que ya conocemos
# lista_modifcada son todos los atgributos modificados
def agregar_los_vacios(id, lista_modificada, conexion):
    cursorinsert = conexion.cursor()
    consulta = "SELECT * from Jugador"
    cursorinsert.execute(consulta)
    lista = cursorinsert.fetchone()
    cursorinsert.commit()
    cursorinsert.close()
    while True:
        if lista_modificada[1] == "":
            lista_modificada[1] = lista[1]
        elif lista_modificada[2] == "":
            lista_modificada[2] = lista[2]
        elif lista_modificada[3] == "":
            lista_modificada[3] = lista[3]
        elif lista_modificada[4] == "":
            lista_modificada[4] = lista[4]
            lista_modificada[5] = recortar_nombre_pais(lista[4])
        elif lista_modificada[6] == "":
            lista_modificada[6] = lista[5]
        elif lista_modificada[7] == "":
            lista_modificada[7] = lista[6]
        elif lista_modificada[8] == "":
            lista_modificada[8] = lista[7]
        elif lista_modificada[9] == "":
            lista_modificada[9] = lista[8]
        else:
            break
    print(lista, lista_modificada, lista_modificada)
    cursorinsert = conexion.cursor()
    consulta = "UPDATE Jugador SET NombreJugador='" + lista_modificada[1] + "', ApellidoJugador='" + lista_modificada[2] + "', AKAJugador='" + lista_modificada[3] + "', PaisJugador='" + lista_modificada[4] + "', AbreviacionPais='" + recortar_nombre_pais(lista_modificada[4]) + "', EquipoJugador='" + lista_modificada[6] + "', FechaNacimiento='" + lista_modificada[7] + "', Genero='" + lista_modificada[8] + "', RolJugador='" + lista_modificada[9] + "' where JugadorID='"+id+"'"
    cursorinsert.execute(consulta)
    cursorinsert.commit()
    cursorinsert.close()
