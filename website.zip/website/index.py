from flask import Flask, render_template, request
from model.view import ver_jugadores, ver_jugador, agregar_los_vacios
from model.ingreso import ingreso_jugador
import pyodbc as sql

app = Flask(__name__)
conexion = sql.connect(
    'DRIVER={ODBC Driver 17 for SQL Server};SERVER=JAVIER-PC\MSSQLSERVER2021;DATABASE=bdjugadores;UID=sa;PWD=skater11')


# conexion

@app.route('/')
def home():
    return render_template('home.html')


@app.route('/insert')
def insert():
    return render_template('insert.html')


@app.route('/save_insert', methods=['POST'])
def save_insert():
    if request.method == 'POST':
        nombre = request.form['nombre jugador']
        apellido = request.form['apellido jugador']
        aka = request.form['aka jugador']
        pais = request.form['pais jugador']
        equipo = request.form['equipo jugador']
        fecha_naci = request.form['cumple jugador']
        genero = request.form['genero jugador']
        rol = request.form['rol jugador']
        print(nombre, apellido, aka, pais, equipo, fecha_naci, genero, rol)
        ingreso_jugador(nombre, apellido, aka, pais, equipo, fecha_naci, genero, rol, conexion)
        return render_template('save_insert.html')
    return "error"


@app.route("/edit")
def edit():
    data = ver_jugadores(conexion)
    print(data)
    return render_template('edit.html', jugadores=data)


@app.route("/edit-2", methods=["POST"])
def edit_2():
    if request.method == 'POST':
        id = request.form['id jugador']
        # update_jugador(id)
        # datos=jugador(id)
        datos = ver_jugador(id, conexion)
    return render_template('edit-2.html', datos=datos[0])


@app.route('/save_edit', methods=['POST'])
def save_edit():
    if request.method == 'POST':
        ide = request.form['id']
        nombre = request.form['nombre jugador']
        apellido = request.form['apellido jugador']
        aka = request.form['aka jugador']
        pais = request.form['pais jugador']
        paisabr = request.form['pais abr']
        equipo = request.form['equipo jugador']
        fecha_naci = request.form['cumple jugador']
        genero = request.form['genero jugador']
        rol = request.form['rol jugador']
        print(ide, nombre, apellido, aka, pais, paisabr, equipo, fecha_naci, genero, rol)
        agregar_los_vacios(ide, [ide, nombre, apellido, aka, pais, paisabr, equipo, fecha_naci, genero, rol], conexion)

        return render_template('save_edit.html')
    return "error"


@app.route("/view")
def view():
    data = ver_jugadores(conexion)
    print(data)
    return render_template('view.html', jugadores=data)


@app.route("/view-2", methods=["POST"])
def view_2():
    if request.method == 'POST':
        id = request.form['id']
        # data = (1, "juan", "pere", "juanito", "chl", "xxx", "34343", "5345", "m", "sniper")
        data = ver_jugador(id, conexion)
        print(data)
    return render_template('view-2.html', jugador=data[0])


@app.route("/delete")
def delete():
    return render_template('delete.html')


@app.route("/delete-2", methods=['POST'])
def delete_2():
    if request.form['id']:
        id = request.form['id']
        data = (1, "juan", "pere", "juanito", "chl", "xxx", "34343", "5345", "m", "sniper")
        # data = view_jugador(id)
        return render_template('delete-2.html', jugador=data)

    return render_template('delete-2.html')


@app.route("/save-delete")
def save_delete():
    return render_template('save-delete.html')


if __name__ == '__main__':
    app.run(port=3000, debug=True)
